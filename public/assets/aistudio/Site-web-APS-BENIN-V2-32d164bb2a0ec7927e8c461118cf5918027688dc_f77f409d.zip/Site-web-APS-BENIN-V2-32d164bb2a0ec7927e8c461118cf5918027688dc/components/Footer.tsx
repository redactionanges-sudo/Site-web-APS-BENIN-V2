'use client';

import React from 'react';
import Link from 'next/link';
import { useLanguage } from '@/lib/i18n';
import { useSiteSettings, sanitizePhoneForTel } from '@/hooks/useSiteSettings';
import { SiteLogo } from '@/components/SiteLogo';
import {
  MapPin,
  Phone,
  Mail,
  ShieldCheck,
  FileText,
  Lock,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  Youtube,
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { language, t } = useLanguage();
  const currentYear = new Date().getFullYear();
  const {
    orgName,
    orgNameShort,
    sloganFr,
    sloganEn,
    addressLocation,
    addressLocality,
    postalBox,
    validPhones,
    email,
    activeSocials,
    settings,
  } = useSiteSettings();

  const renderSocialIcon = (id: string, badge: string) => {
    switch (id) {
      case 'facebook':
        return <Facebook className="w-4 h-4" />;
      case 'twitter':
      case 'x':
        return <Twitter className="w-4 h-4" />;
      case 'linkedin':
        return <Linkedin className="w-4 h-4" />;
      case 'instagram':
        return <Instagram className="w-4 h-4" />;
      case 'youtube':
        return <Youtube className="w-4 h-4" />;
      default:
        return <span className="text-[11px] font-bold tracking-tight">{badge}</span>;
    }
  };

  const currentSlogan = language === 'en' ? (sloganEn || sloganFr) : (sloganFr || sloganEn);

  return (
    <footer className="bg-gray-950 text-gray-300 pt-16 pb-12 border-t-4 border-[#92278F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-12 pb-12 border-b border-gray-800">
          {/* Column 1: Organization identity */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <SiteLogo variant="footer" />
              <div>
                <span className="font-extrabold text-lg text-white tracking-tight font-heading">
                  {orgNameShort || 'APS-BÉNIN'}
                </span>
                <p className="text-[10px] text-gray-400 font-medium tracking-wider">
                  {orgName || 'AGISSONS POUR SAUVER'}
                </p>
              </div>
            </div>

            {currentSlogan && (
              <p className="text-sm text-gray-300 italic font-medium border-l-2 border-[#FF8C00] pl-3 py-1">
                « {currentSlogan} »
              </p>
            )}

            <p className="text-xs text-gray-400 leading-relaxed">
              {language === 'en'
                ? (settings.description_en || 'Non-Governmental Organization committed to human rights, gender equality, sexual and reproductive health, and grassroots community empowerment across Benin.')
                : (settings.description_fr || "Organisation Non Gouvernementale engagée dans la défense des droits humains, la promotion de l'égalité de genre, la santé reproductive et l'autonomisation des communautés vulnérables au Bénin.")}
            </p>

            {/* Social links */}
            {activeSocials.length > 0 && (
              <div className="pt-2">
                <h5 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">
                  {t('footer.follow_us')}
                </h5>
                <div className="flex flex-wrap items-center gap-2">
                  {activeSocials.map((platform) => (
                    <a
                      key={platform.id}
                      href={platform.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-8 h-8 rounded-full bg-gray-800 hover:bg-[#92278F] text-gray-300 hover:text-white flex items-center justify-center transition-colors text-xs font-bold"
                      aria-label={platform.name}
                      title={platform.name}
                    >
                      {renderSocialIcon(platform.id, platform.badge)}
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-4 border-b border-gray-800 pb-2 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#FF8C00]" />
              {t('footer.links_title')}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/" className="hover:text-[#FF8C00] transition-colors">
                  {t('nav.home')}
                </Link>
              </li>
              <li>
                <Link href="/organisation/presentation" className="hover:text-[#FF8C00] transition-colors">
                  {t('nav.presentation')}
                </Link>
              </li>
              <li>
                <Link href="/organisation/histoire" className="hover:text-[#FF8C00] transition-colors">
                  {t('nav.history')}
                </Link>
              </li>
              <li>
                <Link href="/organisation/domaines" className="hover:text-[#FF8C00] transition-colors">
                  {t('nav.domains')}
                </Link>
              </li>
              <li>
                <Link href="/projets" className="hover:text-[#FF8C00] transition-colors">
                  {t('nav.projects')}
                </Link>
              </li>
              <li>
                <Link href="/actualites" className="hover:text-[#FF8C00] transition-colors">
                  {t('nav.news')}
                </Link>
              </li>
              <li>
                <Link href="/opportunites" className="hover:text-[#FF8C00] transition-colors">
                  {t('nav.opportunities')}
                </Link>
              </li>
              <li>
                <Link href="/mediatheque/photos" className="hover:text-[#FF8C00] transition-colors">
                  {t('nav.mediatheque')}
                </Link>
              </li>
              <li>
                <Link href="/partenaires" className="hover:text-[#FF8C00] transition-colors">
                  {t('nav.partners')}
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-[#FF8C00] transition-colors">
                  {t('nav.contact')}
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Headquarters & Contact */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-4 border-b border-gray-800 pb-2 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#FF8C00]" />
              {t('footer.headquarters')}
            </h4>
            <div className="space-y-3 text-xs text-gray-300">
              {(addressLocation || addressLocality || postalBox) && (
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-[#FF8C00] shrink-0 mt-0.5" />
                  <div>
                    {(addressLocation || addressLocality) && (
                      <p className="font-semibold text-white leading-relaxed">
                        {addressLocation || addressLocality}
                      </p>
                    )}
                    {postalBox && (
                      <p className="text-gray-400 mt-1 leading-relaxed">
                        {postalBox}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {validPhones.length > 0 && (
                <div className="flex items-start gap-2.5 pt-1">
                  <Phone className="w-4 h-4 text-[#FF8C00] shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    {validPhones.map((phone, idx) => {
                      const telHref = `tel:${sanitizePhoneForTel(phone)}`;
                      return (
                        <a
                          key={idx}
                          href={telHref}
                          className="block hover:text-white transition-colors"
                        >
                          {phone}
                        </a>
                      );
                    })}
                  </div>
                </div>
              )}

              {email && (
                <div className="flex items-start gap-2.5 pt-1">
                  <Mail className="w-4 h-4 text-[#FF8C00] shrink-0 mt-0.5" />
                  <a
                    href={`mailto:${email}`}
                    className="hover:text-white transition-colors break-all"
                  >
                    {email}
                  </a>
                </div>
              )}
            </div>
          </div>

          {/* Column 4: Institutional & Legal References */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-4 border-b border-gray-800 pb-2 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#92278F]" />
              {t('footer.legal_title')}
            </h4>
            <div className="space-y-2.5 text-xs text-gray-400">
              {(settings.registration_reference || settings.jo_reference) && (
                <div className="p-2.5 rounded bg-gray-900 border border-gray-800">
                  <p className="text-gray-300 font-semibold mb-1 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#FF8C00]" />
                    Enregistrement Officiel
                  </p>
                  {settings.registration_reference && (
                    <p className="text-[11px] leading-tight text-gray-400">
                      {settings.registration_reference}
                    </p>
                  )}
                  {settings.jo_reference && (
                    <p className="text-[11px] leading-tight text-gray-400 mt-1">
                      {settings.jo_reference}
                    </p>
                  )}
                </div>
              )}

              {settings.ifu_number && (
                <div className="p-2.5 rounded bg-gray-900 border border-gray-800">
                  <p className="text-gray-300 font-semibold mb-1 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-[#FF8C00]" />
                    Identifiant Fiscal Unique (IFU)
                  </p>
                  <p className="text-sm font-mono font-bold text-white tracking-wider">
                    {settings.ifu_number}
                  </p>
                </div>
              )}

              <div className="pt-2">
                <Link
                  href="/organisation/documents"
                  className="inline-flex items-center gap-1.5 text-xs text-[#FF8C00] hover:underline font-semibold"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>{t('nav.documents')}</span>
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-500">
          <p>
            © {currentYear} {orgName || 'AGISSONS POUR SAUVER (APS-BÉNIN)'}. {t('footer.rights')}
          </p>

          <div className="flex items-center gap-4">
            <Link href="/mentions-legales" className="hover:text-gray-300 transition-colors">
              {t('footer.terms')}
            </Link>
            <span>•</span>
            <Link href="/politique-confidentialite" className="hover:text-gray-300 transition-colors">
              {t('footer.privacy')}
            </Link>
            <span>•</span>
            <Link
              href="/admin"
              className="flex items-center gap-1 text-[#92278F] hover:text-[#b432b0] font-semibold"
            >
              <Lock className="w-3 h-3 text-[#FF8C00]" />
              <span>{t('nav.admin')}</span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};
